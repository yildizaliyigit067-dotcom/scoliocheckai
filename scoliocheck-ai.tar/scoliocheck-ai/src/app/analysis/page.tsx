'use client';

import { useEffect, useState, useRef } from 'react';
import { useRouter } from 'next/navigation';
import { useScreening } from '@/context/ScreeningContext';
import { runAnalysis, RISK_LABELS } from '@/lib/analysis';
import { PostureCanvas } from '@/components/PostureCanvas';

// ─── Loading phases ────────────────────────────────────────────────────────────
const LOADING_PHASES = [
  { label: 'Loading image…',                    pct: 8  },
  { label: 'Detecting posture landmarks…',      pct: 28 },
  { label: 'Mapping shoulder alignment…',       pct: 46 },
  { label: 'Calculating waist symmetry…',       pct: 62 },
  { label: 'Analysing trunk shift…',            pct: 76 },
  { label: 'Computing asymmetry score…',        pct: 88 },
  { label: 'Generating screening report…',      pct: 96 },
  { label: 'Complete.',                          pct: 100 },
];

// ─── Loading UI ────────────────────────────────────────────────────────────────
function AnalysisLoader({ imageUrl }: { imageUrl: string }) {
  const [phaseIdx,  setPhaseIdx]  = useState(0);
  const [progress,  setProgress]  = useState(0);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    let idx = 0;
    intervalRef.current = setInterval(() => {
      idx++;
      if (idx >= LOADING_PHASES.length) {
        if (intervalRef.current) clearInterval(intervalRef.current);
        return;
      }
      setPhaseIdx(idx);
      setProgress(LOADING_PHASES[idx].pct);
    }, 340);
    return () => { if (intervalRef.current) clearInterval(intervalRef.current); };
  }, []);

  return (
    <div className="flex flex-col items-center">
      {/* Image preview with scan overlay */}
      <div className="relative w-full max-w-xs mb-8 rounded-2xl overflow-hidden">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={imageUrl}
          alt="Being analysed"
          className="w-full object-contain"
          style={{ maxHeight: '280px' }}
        />
        {/* Animated scan line */}
        <div className="absolute inset-0 overflow-hidden rounded-2xl">
          <div
            className="absolute inset-x-0 h-1 bg-gradient-to-r from-transparent via-brand-400 to-transparent opacity-80"
            style={{ animation: 'scan 1.6s linear infinite', top: 0 }}
          />
          {/* Blue tint overlay */}
          <div className="absolute inset-0 bg-brand-900/20 mix-blend-multiply" />
          {/* Grid overlay */}
          <div className="absolute inset-0 dot-bg opacity-30" />
        </div>
        {/* Corner brackets */}
        {[
          'top-2 left-2 border-t-2 border-l-2 rounded-tl-md',
          'top-2 right-2 border-t-2 border-r-2 rounded-tr-md',
          'bottom-2 left-2 border-b-2 border-l-2 rounded-bl-md',
          'bottom-2 right-2 border-b-2 border-r-2 rounded-br-md',
        ].map((cls, i) => (
          <div key={i} className={`absolute w-5 h-5 border-brand-400 ${cls}`} />
        ))}
      </div>

      {/* Status label */}
      <div className="text-center mb-6">
        <p className="font-display font-semibold text-navy text-sm mb-1 animate-pulse-soft">
          {LOADING_PHASES[phaseIdx].label}
        </p>
        <p className="text-[var(--text-muted)] text-xs">
          Analysing posture signals — this takes a few seconds
        </p>
      </div>

      {/* Progress bar */}
      <div className="w-full max-w-xs">
        <div className="flex justify-between text-[10px] text-[var(--text-muted)] mb-1.5">
          <span>Progress</span>
          <span>{progress}%</span>
        </div>
        <div className="w-full h-1.5 bg-slate-100 rounded-full overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-brand-500 to-cyan-500 rounded-full transition-all duration-300"
            style={{ width: `${progress}%` }}
          />
        </div>
      </div>

      {/* Skeleton metric cards */}
      <div className="w-full max-w-xs mt-8 grid grid-cols-2 gap-3">
        {['Shoulder height', 'Waist balance', 'Trunk shift', 'Asymmetry score'].map((label) => (
          <div key={label} className="card p-3">
            <p className="text-[10px] text-[var(--text-muted)] mb-2">{label}</p>
            <div className="h-4 rounded bg-slate-100 animate-pulse" />
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Result detail card ────────────────────────────────────────────────────────
function MetricCard({
  label, value, unit, sub, color,
}: {
  label: string; value: string | number; unit?: string;
  sub?: string; color?: string;
}) {
  return (
    <div className="card p-4">
      <p className="text-[10px] font-semibold text-[var(--text-muted)] uppercase tracking-widest mb-2">{label}</p>
      <p className={`font-display font-bold text-xl ${color ?? 'text-navy'}`}>
        {value}<span className="text-sm font-normal text-[var(--text-muted)] ml-1">{unit}</span>
      </p>
      {sub && <p className="text-[10px] text-[var(--text-muted)] mt-1">{sub}</p>}
    </div>
  );
}

// ─── Main page ─────────────────────────────────────────────────────────────────
export default function AnalysisPage() {
  const router = useRouter();
  const { imageDataUrl, isDemoMode, result, setResult } = useScreening();
  const [isLoading,    setIsLoading]    = useState(true);
  const [canAnimate,   setCanAnimate]   = useState(false);
  const [showResults,  setShowResults]  = useState(false);
  const hasStarted = useRef(false);

  useEffect(() => {
    // Guard: if no image, redirect home
    if (!imageDataUrl) {
      router.replace('/');
      return;
    }
    // Guard: only run analysis once
    if (hasStarted.current) return;
    hasStarted.current = true;

    // If we already have a cached result (e.g. back-navigation), show it
    if (result) {
      setIsLoading(false);
      setTimeout(() => setCanAnimate(true), 200);
      setTimeout(() => setShowResults(true), 800);
      return;
    }

    runAnalysis(imageDataUrl, isDemoMode).then((r) => {
      setResult(r);
      setIsLoading(false);
      setTimeout(() => setCanAnimate(true), 300);
      setTimeout(() => setShowResults(true), 800);
    });
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (!imageDataUrl) return null;

  const riskColorClass = !result ? '' :
    result.riskLevel === 'low'      ? 'text-emerald-600' :
    result.riskLevel === 'moderate' ? 'text-amber-600'   : 'text-red-600';

  const riskBgClass = !result ? '' :
    result.riskLevel === 'low'      ? 'bg-emerald-50 border-emerald-200' :
    result.riskLevel === 'moderate' ? 'bg-amber-50 border-amber-200'     : 'bg-red-50 border-red-200';

  return (
    <div className="min-h-dvh bg-[var(--bg)] flex flex-col">

      {/* ── Nav ─────────────────────────────────────────────────────────── */}
      <header className="bg-white/80 backdrop-blur-md border-b border-[var(--border)] sticky top-0 z-40">
        <div className="max-w-xl mx-auto px-5 h-14 flex items-center justify-between">
          <button
            onClick={() => router.push('/screen')}
            className="flex items-center gap-2 group"
            disabled={isLoading}
          >
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}
              className="w-4 h-4 text-[var(--text-muted)] group-hover:text-navy transition-colors">
              <path strokeLinecap="round" strokeLinejoin="round" d="M10.5 19.5L3 12m0 0l7.5-7.5M3 12h18"/>
            </svg>
            <span className="text-[var(--text-muted)] text-sm group-hover:text-navy transition-colors">Retake</span>
          </button>
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-brand-600" />
            <span className="font-display font-bold text-navy text-sm">ScolioCheck AI</span>
          </div>
          <span className="text-[var(--text-muted)] text-xs">Step 2 of 3</span>
        </div>
      </header>

      {/* ── Progress bar ─────────────────────────────────────────────────── */}
      <div className="h-1 bg-slate-100">
        <div className={`h-1 bg-brand-600 transition-all duration-700 ${isLoading ? 'w-1/2' : 'w-2/3'}`} />
      </div>

      <main className="flex-1 max-w-xl mx-auto w-full px-5 py-8 pb-32">

        {isLoading ? (
          // ── Loading state ─────────────────────────────────────────────
          <div className="animate-fade-in">
            <div className="mb-6">
              <h1 className="font-display font-bold text-navy text-xl mb-1">
                Analysing posture signals…
              </h1>
              <p className="text-[var(--text-muted)] text-sm">
                AI is mapping shoulder, waist, and trunk landmarks.
              </p>
            </div>
            <AnalysisLoader imageUrl={imageDataUrl} />
          </div>
        ) : result ? (
          // ── Analysis complete ─────────────────────────────────────────
          <div className="animate-fade-in">

            {/* Header */}
            <div className="mb-6">
              <div className="flex items-center gap-2 mb-2">
                <span className={`label-tag border ${riskBgClass} ${riskColorClass} text-[10px]`}>
                  {isDemoMode && 'Demo · '}
                  {RISK_LABELS[result.riskLevel]}
                </span>
                {isDemoMode && (
                  <span className="label-tag bg-amber-100 text-amber-700 text-[10px]">Sample data</span>
                )}
              </div>
              <h1 className="font-display font-bold text-navy text-xl">
                Posture analysis complete
              </h1>
              <p className="text-[var(--text-muted)] text-sm mt-1">
                Visual asymmetry markers have been mapped below.
                These are demo screening indicators, not clinical measurements.
              </p>
            </div>

            {/* Canvas overlay image */}
            <div className="mb-6 animate-fade-up opacity-0" style={{ animationFillMode: 'forwards' }}>
              <PostureCanvas
                imageUrl={imageDataUrl}
                result={result}
                animate={canAnimate}
              />
              {/* Legend */}
              <div className="flex flex-wrap gap-3 mt-3 justify-center">
                {[
                  { color: 'bg-white/90 border border-white', label: 'Spine guide' },
                  {
                    color: result.riskLevel === 'low' ? 'bg-emerald-500' :
                           result.riskLevel === 'moderate' ? 'bg-amber-500' : 'bg-red-500',
                    label: 'Shoulder line',
                  },
                  { color: 'bg-sky-500', label: 'Waist line' },
                  { color: 'bg-amber-400', label: 'Height diff' },
                ].map(({ color, label }) => (
                  <div key={label} className="flex items-center gap-1.5">
                    <span className={`w-3 h-1.5 rounded-sm ${color}`} />
                    <span className="text-[10px] text-[var(--text-muted)]">{label}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Metric cards */}
            {showResults && (
              <div
                className="grid grid-cols-2 gap-3 mb-6 animate-fade-up opacity-0"
                style={{ animationFillMode: 'forwards' }}
              >
                <MetricCard
                  label="Shoulder height diff"
                  value={result.shoulderHeightDiff}
                  unit="mm"
                  sub="Left vs right shoulder level"
                  color={result.shoulderHeightDiff > 10 ? 'text-amber-600' : 'text-navy'}
                />
                <MetricCard
                  label="Waist imbalance"
                  value={result.waistImbalance}
                  unit="mm"
                  sub="Waist crease symmetry"
                  color={result.waistImbalance > 8 ? 'text-amber-600' : 'text-navy'}
                />
                <MetricCard
                  label="Trunk shift"
                  value={result.trunkShift}
                  unit="mm"
                  sub="Lateral trunk deviation"
                  color={result.trunkShift > 6 ? 'text-amber-600' : 'text-navy'}
                />
                <MetricCard
                  label="Asymmetry score"
                  value={result.asymmetryScore}
                  unit="/ 100"
                  sub="Overall screening indicator"
                  color={riskColorClass}
                />
              </div>
            )}

            {/* Disclaimer */}
            <div className="disclaimer-box mb-6 animate-fade-up opacity-0 stagger-3" style={{ animationFillMode: 'forwards' }}>
              <strong>Demo screening indicators only.</strong> These values are not clinical
              measurements. Shoulder height difference, waist imbalance, trunk shift, and asymmetry
              score are visual estimation metrics for demonstration purposes only.
              Do not use these results for any medical decision.
            </div>

          </div>
        ) : null}

      </main>

      {/* ── Fixed bottom CTA ─────────────────────────────────────────────── */}
      {!isLoading && result && (
        <div className="fixed bottom-0 inset-x-0 bg-white/90 backdrop-blur-md border-t border-[var(--border)] px-5 py-4 z-30">
          <div className="max-w-xl mx-auto flex gap-3">
            <button
              onClick={() => router.push('/screen')}
              className="btn-secondary flex-1"
            >
              Retake
            </button>
            <button
              onClick={() => router.push('/results')}
              className="btn-primary flex-1"
            >
              View full report →
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
