'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useScreening } from '@/context/ScreeningContext';
import { RISK_LABELS } from '@/lib/analysis';
import { ReportCard } from '@/components/ReportCard';

// ─── Next-step action card ─────────────────────────────────────────────────────
function ActionCard({
  icon, title, description, cta, onClick, variant = 'default',
}: {
  icon:        React.ReactNode;
  title:       string;
  description: string;
  cta:         string;
  onClick:     () => void;
  variant?:    'default' | 'primary' | 'muted';
}) {
  const base    = 'card p-5 flex flex-col gap-3 cursor-pointer transition-all duration-150 hover:shadow-card-lg active:scale-[0.99]';
  const primary = 'bg-brand-600 border-brand-500 text-white hover:bg-brand-700';

  return (
    <div
      className={`${base} ${variant === 'primary' ? primary : ''}`}
      onClick={onClick}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => e.key === 'Enter' && onClick()}
    >
      <div className={`w-9 h-9 rounded-xl flex items-center justify-center
        ${variant === 'primary' ? 'bg-white/20' : 'bg-brand-50'}`}>
        <span className={variant === 'primary' ? 'text-white' : 'text-brand-600'}>{icon}</span>
      </div>
      <div>
        <h3 className={`font-display font-semibold text-sm mb-0.5 ${variant === 'primary' ? 'text-white' : 'text-navy'}`}>
          {title}
        </h3>
        <p className={`text-xs leading-relaxed ${variant === 'primary' ? 'text-white/70' : 'text-[var(--text-muted)]'}`}>
          {description}
        </p>
      </div>
      <span className={`text-xs font-semibold ${variant === 'primary' ? 'text-white' : 'text-brand-600'}`}>
        {cta} →
      </span>
    </div>
  );
}

// ─── Copy summary helper ──────────────────────────────────────────────────────
function buildSummaryText(result: ReturnType<typeof useScreening>['result']): string {
  if (!result) return '';
  const date = new Intl.DateTimeFormat('en-GB', { dateStyle: 'long', timeStyle: 'short' }).format(new Date(result.date));
  return `ScolioCheck AI — Posture Screening Report
Report ID: ${result.id}
Date: ${date}
${result.isDemoMode ? '⚠ Demo data — not from a real screening\n' : ''}
─────────────────────────────────────────
SCREENING RESULT: ${RISK_LABELS[result.riskLevel]}
Asymmetry Score: ${result.asymmetryScore} / 100

OBSERVED SIGNALS
• Shoulder Height Difference: ${result.shoulderHeightDiff} mm
• Waist Imbalance: ${result.waistImbalance} mm
• Trunk Shift: ${result.trunkShift} mm

─────────────────────────────────────────
DISCLAIMER
ScolioCheck AI does not diagnose scoliosis.
Only a qualified clinician can diagnose scoliosis
through physical examination and imaging.

This report is for demonstration purposes only
and must not be used for any medical decision.
─────────────────────────────────────────
ScolioCheck AI · Early Prototype · Not a medical device`;
}

// ─── Main page ────────────────────────────────────────────────────────────────
export default function ResultsPage() {
  const router = useRouter();
  const { result, isDemoMode, imageDataUrl, reset } = useScreening();
  const [copied, setCopied] = useState(false);
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  // Guard: redirect if no result
  if (!result || !imageDataUrl) {
    // Render a minimal skeleton until effect runs
    return (
      <div className="min-h-dvh flex items-center justify-center bg-[var(--bg)]">
        <div className="text-center">
          <div className="w-8 h-8 border-2 border-brand-600 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="text-[var(--text-muted)] text-sm">Loading results…</p>
          <button onClick={() => router.push('/')} className="mt-4 btn-ghost text-brand-600">
            Back to home
          </button>
        </div>
      </div>
    );
  }

  function showToast(msg: string) {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 3000);
  }

  async function handleCopy() {
    const text = buildSummaryText(result);
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      showToast('Report copied to clipboard');
      setTimeout(() => setCopied(false), 3000);
    } catch {
      showToast('Could not access clipboard — please copy manually');
    }
  }

  function handlePrint() {
    window.print();
  }

  function handleRetake() {
    reset();
    router.push('/screen');
  }

  function handleNewScreening() {
    reset();
    router.push('/');
  }

  function handleDoctorInfo() {
    showToast('In the full product, this would provide local specialist finder and referral guidance.');
  }

  const isUrgent = result.riskLevel === 'high';
  const isConcern = result.riskLevel !== 'low';

  const resultHeadline = result.riskLevel === 'low'
    ? 'No urgent concern detected in this demo'
    : 'Visible asymmetry detected — evaluation may be helpful';

  const resultSubhead = result.riskLevel === 'low'
    ? 'Postural landmarks appeared largely symmetrical during this screening. Continue routine monitoring.'
    : result.riskLevel === 'moderate'
    ? 'Some visible posture differences were observed. A medical evaluation would be a sensible next step.'
    : 'Notable visible asymmetry was observed. We recommend consulting a healthcare professional.';

  return (
    <div className="min-h-dvh bg-[var(--bg)] flex flex-col">

      {/* ── Toast notification ────────────────────────────────────────── */}
      {toastMsg && (
        <div className="fixed top-4 left-1/2 -translate-x-1/2 z-50 no-print
                        bg-navy text-white text-xs font-medium px-4 py-2.5 rounded-xl shadow-lg
                        animate-fade-up">
          {toastMsg}
        </div>
      )}

      {/* ── Nav ─────────────────────────────────────────────────────────── */}
      <header className="bg-white/80 backdrop-blur-md border-b border-[var(--border)] sticky top-0 z-40 no-print">
        <div className="max-w-xl mx-auto px-5 h-14 flex items-center justify-between">
          <button onClick={() => router.push('/analysis')} className="flex items-center gap-2 group">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}
              className="w-4 h-4 text-[var(--text-muted)] group-hover:text-navy transition-colors">
              <path strokeLinecap="round" strokeLinejoin="round" d="M10.5 19.5L3 12m0 0l7.5-7.5M3 12h18"/>
            </svg>
            <span className="text-[var(--text-muted)] text-sm group-hover:text-navy transition-colors">Back</span>
          </button>
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-brand-600" />
            <span className="font-display font-bold text-navy text-sm">ScolioCheck AI</span>
          </div>
          <span className="text-[var(--text-muted)] text-xs">Step 3 of 3</span>
        </div>
      </header>

      {/* ── Progress bar ─────────────────────────────────────────────────── */}
      <div className="h-1 bg-slate-100 no-print">
        <div className="h-1 bg-brand-600 w-full transition-all duration-700" />
      </div>

      <main className="flex-1 max-w-xl mx-auto w-full px-5 py-8 pb-36">

        {/* ── Result banner ────────────────────────────────────────────── */}
        <div
          className={`rounded-2xl p-5 mb-6 border animate-fade-up opacity-0 no-print
            ${result.riskLevel === 'low'
              ? 'bg-emerald-50 border-emerald-200'
              : result.riskLevel === 'moderate'
              ? 'bg-amber-50 border-amber-200'
              : 'bg-red-50 border-red-200'}`}
          style={{ animationFillMode: 'forwards' }}
        >
          <div className="flex items-start gap-3">
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 font-display font-bold text-lg
              ${result.riskLevel === 'low' ? 'bg-emerald-100 text-emerald-700' :
                result.riskLevel === 'moderate' ? 'bg-amber-100 text-amber-700' : 'bg-red-100 text-red-700'}`}>
              {result.riskLevel === 'low' ? '✓' : result.riskLevel === 'moderate' ? '!' : '!!'}
            </div>
            <div>
              <h1 className={`font-display font-bold text-base mb-1
                ${result.riskLevel === 'low' ? 'text-emerald-800' :
                  result.riskLevel === 'moderate' ? 'text-amber-800' : 'text-red-800'}`}>
                {resultHeadline}
              </h1>
              <p className={`text-sm leading-relaxed
                ${result.riskLevel === 'low' ? 'text-emerald-700' :
                  result.riskLevel === 'moderate' ? 'text-amber-700' : 'text-red-700'}`}>
                {resultSubhead}
              </p>
            </div>
          </div>
          {isDemoMode && (
            <div className="mt-3 pt-3 border-t border-current/10">
              <p className={`text-xs font-medium
                ${result.riskLevel === 'low' ? 'text-emerald-600' :
                  result.riskLevel === 'moderate' ? 'text-amber-600' : 'text-red-600'}`}>
                ⚠ Demo data: These results are simulated for demonstration purposes.
              </p>
            </div>
          )}
        </div>

        {/* ── Report card ─────────────────────────────────────────────── */}
        <div
          className="mb-6 animate-fade-up opacity-0 stagger-2"
          style={{ animationFillMode: 'forwards' }}
        >
          <ReportCard result={result} />
        </div>

        {/* ── Action bar (save / print / copy) ─────────────────────────── */}
        <div
          className="flex gap-3 mb-8 no-print animate-fade-up opacity-0 stagger-3"
          style={{ animationFillMode: 'forwards' }}
        >
          <button
            onClick={handleCopy}
            className="btn-secondary flex-1 text-xs py-2.5"
          >
            {copied ? (
              <><span>✓</span> Copied</>
            ) : (
              <>
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} className="w-3.5 h-3.5">
                  <path strokeLinecap="round" d="M15.666 3.888A2.25 2.25 0 0013.5 2.25h-3c-1.03 0-1.9.693-2.166 1.638m7.332 0c.055.194.084.4.084.612v0a.75.75 0 01-.75.75H9a.75.75 0 01-.75-.75v0c0-.212.03-.418.084-.612m7.332 0c.646.049 1.288.11 1.927.184 1.1.128 1.907 1.077 1.907 2.185V19.5a2.25 2.25 0 01-2.25 2.25H6.75A2.25 2.25 0 014.5 19.5V6.257c0-1.108.806-2.057 1.907-2.185a48.208 48.208 0 011.927-.184"/>
                </svg>
                Copy report
              </>
            )}
          </button>
          <button
            onClick={handlePrint}
            className="btn-secondary flex-1 text-xs py-2.5"
          >
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} className="w-3.5 h-3.5">
              <path strokeLinecap="round" d="M6.72 13.829c-.24.03-.48.062-.72.096m.72-.096a42.415 42.415 0 0110.56 0m-10.56 0L6.34 18m10.94-4.171c.24.03.48.062.72.096m-.72-.096L17.66 18m0 0l.229 2.523a1.125 1.125 0 01-1.12 1.227H7.231c-.662 0-1.18-.568-1.12-1.227L6.34 18m11.318 0h1.091A2.25 2.25 0 0021 15.75V9.456c0-1.081-.768-2.015-1.837-2.175a48.055 48.055 0 00-1.913-.247M6.34 18H5.25A2.25 2.25 0 013 15.75V9.456c0-1.081.768-2.015 1.837-2.175a48.041 48.041 0 011.913-.247m10.5 0a48.536 48.536 0 00-10.5 0m10.5 0V3.375c0-.621-.504-1.125-1.125-1.125h-8.25c-.621 0-1.125.504-1.125 1.125v3.659M18 10.5h.008v.008H18V10.5zm-3 0h.008v.008H15V10.5z"/>
            </svg>
            Print / Save PDF
          </button>
        </div>

        {/* ── Next steps ───────────────────────────────────────────────── */}
        <div className="mb-8 no-print animate-fade-up opacity-0 stagger-4" style={{ animationFillMode: 'forwards' }}>
          <h2 className="font-display font-bold text-navy text-base mb-4">
            What to do next
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {isConcern && (
              <ActionCard
                variant="primary"
                icon={
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} className="w-5 h-5">
                    <path strokeLinecap="round" d="M15.75 10.5l4.72-4.72a.75.75 0 011.28.53v11.38a.75.75 0 01-1.28.53l-4.72-4.72M4.5 18.75h9a2.25 2.25 0 002.25-2.25v-9a2.25 2.25 0 00-2.25-2.25h-9A2.25 2.25 0 002.25 7.5v9a2.25 2.25 0 002.25 2.25z"/>
                  </svg>
                }
                title="Talk to a doctor"
                description={isUrgent ? "Seek a medical evaluation soon." : "Discuss these findings with your paediatrician or GP."}
                cta="Find a specialist"
                onClick={handleDoctorInfo}
              />
            )}
            <ActionCard
              icon={
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} className="w-5 h-5">
                  <path strokeLinecap="round" d="M16.023 9.348h4.992v-.001M2.985 19.644v-4.992m0 0h4.992m-4.993 0l3.181 3.183a8.25 8.25 0 0013.803-3.7M4.031 9.865a8.25 8.25 0 0113.803-3.7l3.181 3.182m0-4.991v4.99"/>
                </svg>
              }
              title="Retake screening"
              description="Ensure good lighting and a clear back view for best accuracy."
              cta="New photo"
              onClick={handleRetake}
            />
            <ActionCard
              icon={
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} className="w-5 h-5">
                  <path strokeLinecap="round" d="M2.25 12l8.954-8.955c.44-.439 1.152-.439 1.591 0L21.75 12M4.5 9.75v10.125c0 .621.504 1.125 1.125 1.125H9.75v-4.875c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125V21h4.125c.621 0 1.125-.504 1.125-1.125V9.75M8.25 21h8.25"/>
                </svg>
              }
              title="Back to home"
              description="Start a new session or learn more about ScolioCheck AI."
              cta="Home"
              onClick={handleNewScreening}
            />
          </div>
        </div>

        {/* ── Strong final disclaimer ───────────────────────────────────── */}
        <div className="disclaimer-box no-print animate-fade-up opacity-0 stagger-5" style={{ animationFillMode: 'forwards' }}>
          <div className="flex gap-3">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}
              className="w-4 h-4 flex-shrink-0 mt-0.5 text-amber-600">
              <path strokeLinecap="round" d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126zM12 15.75h.007v.008H12v-.008z"/>
            </svg>
            <div>
              <strong className="block mb-1">ScolioCheck AI does not diagnose scoliosis.</strong>
              Only a qualified clinician — typically through physical examination and spinal X-ray —
              can diagnose scoliosis. This screening tool identifies possible visible asymmetry to
              help families decide whether a medical evaluation is appropriate. It is not a medical
              device, clinical tool, or substitute for professional healthcare.
            </div>
          </div>
        </div>

      </main>

      {/* ── Fixed bottom nav ──────────────────────────────────────────────── */}
      <div className="fixed bottom-0 inset-x-0 bg-white/90 backdrop-blur-md border-t border-[var(--border)] px-5 py-4 z-30 no-print">
        <div className="max-w-xl mx-auto flex gap-3">
          <button onClick={handleRetake}    className="btn-secondary flex-1 text-sm">Retake photo</button>
          {isConcern ? (
            <button onClick={handleDoctorInfo} className="btn-primary flex-1 text-sm">Find a doctor →</button>
          ) : (
            <button onClick={handleNewScreening} className="btn-primary flex-1 text-sm">New screening →</button>
          )}
        </div>
      </div>
    </div>
  );
}
