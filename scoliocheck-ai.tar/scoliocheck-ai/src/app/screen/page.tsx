'use client';

import { useState, useRef, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import { useScreening } from '@/context/ScreeningContext';
import { getSampleImageDataUrl } from '@/lib/sampleImage';

// ─── Instruction step data ────────────────────────────────────────────────────
const STEPS = [
  {
    icon: '👕',
    title: 'Wear fitted clothing',
    description: 'A fitted t-shirt or tank top works best. Loose clothing can hide postural signals.',
  },
  {
    icon: '🧍',
    title: 'Stand naturally upright',
    description: 'Stand with feet hip-width apart. Do not force posture. Breathe normally and relax shoulders.',
  },
  {
    icon: '📸',
    title: 'Take a back-facing photo',
    description: 'Camera should be at shoulder height, about 1–2 metres away. The photo should show the full back.',
  },
  {
    icon: '☀️',
    title: 'Use good, even lighting',
    description: 'Stand facing a plain wall with light coming from in front. Avoid backlighting or harsh shadows.',
  },
  {
    icon: '📐',
    title: 'Keep shoulders & waist visible',
    description: 'The whole back from the base of the neck down to the hips should be visible in the frame.',
  },
];

// ─── Step indicator ───────────────────────────────────────────────────────────
function GuideStep({
  n, icon, title, description, isLast,
}: { n: number; icon: string; title: string; description: string; isLast: boolean }) {
  return (
    <div className="flex gap-4">
      <div className="flex flex-col items-center">
        <div className="w-9 h-9 rounded-full bg-brand-50 border-2 border-brand-200 flex items-center justify-center flex-shrink-0">
          <span className="text-base">{icon}</span>
        </div>
        {!isLast && <div className="w-0.5 flex-1 mt-2 bg-brand-100 min-h-[24px]" />}
      </div>
      <div className={`pb-6 ${isLast ? '' : ''}`}>
        <div className="flex items-center gap-2 mb-0.5">
          <span className="text-[10px] text-brand-600 font-bold uppercase tracking-widest">Step {n}</span>
        </div>
        <h3 className="font-display font-semibold text-navy text-sm mb-1">{title}</h3>
        <p className="text-[var(--text-muted)] text-xs leading-relaxed">{description}</p>
      </div>
    </div>
  );
}

// ─── Upload zone ──────────────────────────────────────────────────────────────
function UploadZone({
  onFile, preview,
}: {
  onFile:  (file: File) => void;
  preview: string | null;
}) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [dragging, setDragging] = useState(false);

  const handleFile = useCallback(
    (file: File) => {
      if (!file.type.startsWith('image/')) return;
      onFile(file);
    },
    [onFile],
  );

  const onDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragging(false);
    const file = e.dataTransfer.files[0];
    if (file) handleFile(file);
  };

  if (preview) {
    return (
      <div className="relative rounded-2xl overflow-hidden border-2 border-brand-200 bg-slate-50">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src={preview} alt="Uploaded posture photo" className="w-full object-contain max-h-80" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent" />
        <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between">
          <span className="text-white text-xs font-semibold bg-black/40 px-2 py-1 rounded-lg">
            ✓ Image ready
          </span>
          <button
            onClick={() => inputRef.current?.click()}
            className="text-white text-xs bg-black/40 px-3 py-1.5 rounded-lg font-medium hover:bg-black/60 transition-colors"
          >
            Change
          </button>
        </div>
        <input
          ref={inputRef} type="file" accept="image/*" className="hidden"
          onChange={(e) => { const f = e.target.files?.[0]; if (f) handleFile(f); }}
        />
      </div>
    );
  }

  return (
    <div
      className={`relative rounded-2xl border-2 border-dashed transition-all duration-200 cursor-pointer
        ${dragging
          ? 'border-brand-500 bg-brand-50'
          : 'border-[var(--border)] bg-white hover:border-brand-300 hover:bg-brand-50/30'}`}
      onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
      onDragLeave={() => setDragging(false)}
      onDrop={onDrop}
      onClick={() => inputRef.current?.click()}
    >
      <input
        ref={inputRef} type="file" accept="image/*" className="hidden"
        onChange={(e) => { const f = e.target.files?.[0]; if (f) handleFile(f); }}
      />
      <div className="flex flex-col items-center justify-center py-12 px-6 text-center">
        <div className="w-14 h-14 rounded-2xl bg-brand-50 flex items-center justify-center mb-4">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.5}
            className="w-7 h-7 text-brand-500">
            <path strokeLinecap="round" strokeLinejoin="round"
              d="M3 16.5v2.25A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75V16.5m-13.5-9L12 3m0 0l4.5 4.5M12 3v13.5"/>
          </svg>
        </div>
        <p className="text-navy font-semibold text-sm mb-1">
          {dragging ? 'Drop image here' : 'Tap to upload photo'}
        </p>
        <p className="text-[var(--text-muted)] text-xs">
          JPG, PNG, HEIC · Max 20 MB
        </p>
        <p className="text-[var(--text-muted)] text-xs mt-3 opacity-70">
          Your photo is processed locally and never stored or transmitted.
        </p>
      </div>
    </div>
  );
}

// ─── Main page ────────────────────────────────────────────────────────────────
export default function ScreenPage() {
  const router               = useRouter();
  const { setImage }         = useScreening();
  const [preview, setPreview] = useState<string | null>(null);
  const [isReady, setIsReady] = useState(false);

  const handleFile = useCallback((file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const dataUrl = e.target?.result as string;
      setPreview(dataUrl);
      setIsReady(true);
    };
    reader.readAsDataURL(file);
  }, []);

  function handleAnalyze() {
    if (!preview) return;
    setImage(preview, false);
    router.push('/analysis');
  }

  function handleDemo() {
    const dataUrl = getSampleImageDataUrl();
    setImage(dataUrl, true);
    router.push('/analysis');
  }

  return (
    <div className="min-h-dvh bg-[var(--bg)] flex flex-col">

      {/* ── Nav ─────────────────────────────────────────────────────────── */}
      <header className="bg-white/80 backdrop-blur-md border-b border-[var(--border)] sticky top-0 z-40">
        <div className="max-w-xl mx-auto px-5 h-14 flex items-center justify-between">
          <button onClick={() => router.push('/')} className="flex items-center gap-2 group">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}
              className="w-4 h-4 text-[var(--text-muted)] group-hover:text-navy transition-colors">
              <path strokeLinecap="round" strokeLinejoin="round" d="M10.5 19.5L3 12m0 0l7.5-7.5M3 12h18"/>
            </svg>
            <span className="text-[var(--text-muted)] text-sm group-hover:text-navy transition-colors">Back</span>
          </button>
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-brand-600" />
            <span className="font-display font-bold text-navy text-sm">ScolioCheck AI</span>
          </div>
          {/* Progress */}
          <span className="text-[var(--text-muted)] text-xs">Step 1 of 3</span>
        </div>
      </header>

      {/* ── Progress bar ─────────────────────────────────────────────────── */}
      <div className="h-1 bg-slate-100">
        <div className="h-1 bg-brand-600 w-1/3 transition-all duration-500" />
      </div>

      <main className="flex-1 max-w-xl mx-auto w-full px-5 py-8 pb-24">

        {/* Page header */}
        <div className="mb-8 animate-fade-up opacity-0" style={{ animationFillMode: 'forwards' }}>
          <h1 className="font-display font-bold text-navy text-2xl mb-2">
            Prepare your screening photo
          </h1>
          <p className="text-[var(--text-muted)] text-sm leading-relaxed">
            Follow these guidelines to ensure the most accurate visual assessment.
            Image quality directly affects screening confidence.
          </p>
        </div>

        {/* Instruction guide */}
        <div className="card p-5 mb-6 animate-fade-up opacity-0 stagger-2" style={{ animationFillMode: 'forwards' }}>
          <h2 className="font-display font-semibold text-navy text-sm mb-4 flex items-center gap-2">
            <span className="w-5 h-5 rounded bg-brand-100 text-brand-700 flex items-center justify-center text-xs font-bold">?</span>
            Photo guidelines
          </h2>
          <div>
            {STEPS.map((step, i) => (
              <GuideStep
                key={i}
                n={i + 1}
                icon={step.icon}
                title={step.title}
                description={step.description}
                isLast={i === STEPS.length - 1}
              />
            ))}
          </div>
        </div>

        {/* Upload zone */}
        <div className="mb-4 animate-fade-up opacity-0 stagger-3" style={{ animationFillMode: 'forwards' }}>
          <UploadZone onFile={handleFile} preview={preview} />
        </div>

        {/* Demo sample option */}
        <div className="mb-6 animate-fade-up opacity-0 stagger-4" style={{ animationFillMode: 'forwards' }}>
          <button
            onClick={handleDemo}
            className="w-full flex items-center justify-center gap-2 py-3 px-4
                       border border-dashed border-brand-300 rounded-xl
                       text-brand-600 text-sm font-medium
                       hover:bg-brand-50 transition-colors duration-150"
          >
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} className="w-4 h-4">
              <path strokeLinecap="round" d="M15.59 14.37a6 6 0 01-5.84 7.38v-4.8m5.84-2.58a14.98 14.98 0 006.16-12.12A14.98 14.98 0 009.631 8.41m5.96 5.96a14.926 14.926 0 01-5.841 2.58m-.119-8.54a6 6 0 00-7.381 5.84h4.8m2.581-5.84a14.927 14.927 0 00-2.58 5.84m2.699 2.7c-.103.021-.207.041-.311.06a15.09 15.09 0 01-2.448-2.448 14.9 14.9 0 01.06-.312m-2.24 2.39a4.493 4.493 0 00-1.757 4.306 4.493 4.493 0 004.306-1.758M16.5 9a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0z"/>
            </svg>
            Use demo sample image instead
          </button>
          <p className="text-[var(--text-muted)] text-[11px] text-center mt-2">
            The sample image demonstrates the screening with pre-set results.
          </p>
        </div>

        {/* Privacy note */}
        <div className="disclaimer-box mb-6 animate-fade-up opacity-0 stagger-5" style={{ animationFillMode: 'forwards' }}>
          <div className="flex gap-2.5">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} className="w-4 h-4 flex-shrink-0 mt-0.5">
              <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75L11.25 15 15 9.75m-3-7.036A11.959 11.959 0 013.598 6 11.955 11.955 0 003 10c0 5.592 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.31-.21-2.57-.598-3.75h-.152c-3.196 0-6.1-1.249-8.25-3.286z"/>
            </svg>
            <div>
              <strong className="block mb-0.5">Privacy & Safety</strong>
              Your photo is analysed entirely in your browser. Nothing is uploaded to any server.
              All analysis results are simulated for this demo and are not medical measurements.
            </div>
          </div>
        </div>

      </main>

      {/* ── Fixed bottom CTA ─────────────────────────────────────────────── */}
      <div className="fixed bottom-0 inset-x-0 bg-white/90 backdrop-blur-md border-t border-[var(--border)] px-5 py-4 z-30">
        <div className="max-w-xl mx-auto">
          <button
            onClick={handleAnalyze}
            disabled={!isReady}
            className={`w-full btn-primary py-4 text-base transition-all duration-300
              ${isReady
                ? 'opacity-100'
                : 'opacity-40 cursor-not-allowed pointer-events-none'}`}
          >
            {isReady ? (
              <>
                Analyse posture →
              </>
            ) : (
              'Upload a photo to continue'
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
