// ─── Demo Analysis Engine ───────────────────────────────────────────────────
//
// PRODUCTION INTEGRATION NOTE:
// Replace `runAnalysis()` with a call to:
//   1. MediaPipe Pose (browser, free, privacy-preserving): https://mediapipe.dev
//   2. TensorFlow.js MoveNet (browser, free): https://tfhub.dev/google/tfjs-model/movenet
//   3. Your own server-side CV endpoint that accepts the image and returns landmarks
//
// The `Landmarks` structure uses 0-1 fractions so overlay rendering is
// resolution-independent regardless of which model you integrate.
// ─────────────────────────────────────────────────────────────────────────────

import type { AnalysisResult, Landmarks, RiskLevel } from './types';

// ---------------------------------------------------------------------------
// Demo-mode landmarks: tuned to produce a "moderate" reading on the SVG
// silhouette so the YC demo always shows a compelling (non-trivial) result.
// ---------------------------------------------------------------------------
const DEMO_LANDMARKS: Landmarks = {
  leftShoulder:  { x: 0.31, y: 0.225 },
  rightShoulder: { x: 0.69, y: 0.195 },  // ~3% higher → visible asymmetry
  leftWaist:     { x: 0.275, y: 0.580 },
  rightWaist:    { x: 0.715, y: 0.555 }, // ~2.5% higher
  spineTop:      { x: 0.500, y: 0.220 },
  spineBottom:   { x: 0.516, y: 0.730 }, // slight rightward trunk shift
};

const DEMO_METRICS = {
  shoulderHeightDiff: 8.4,  // mm-equivalent
  waistImbalance:     6.2,
  trunkShift:         5.7,
  asymmetryScore:     52,   // → 'moderate'
};

// ---------------------------------------------------------------------------
// For user-uploaded images we generate plausible stochastic landmarks.
// A real model would return accurate landmark coordinates from the image.
// ---------------------------------------------------------------------------
function generateUploadLandmarks(): Landmarks {
  const jitter = (base: number, range: number) =>
    base + (Math.random() * range - range / 2);

  const asymH = jitter(0, 0.06);  // shoulder height asymmetry
  const asymW = jitter(0, 0.04);  // waist asymmetry
  const trunkShiftX = jitter(0, 0.02);

  return {
    leftShoulder:  { x: jitter(0.31, 0.03), y: jitter(0.22, 0.03) },
    rightShoulder: { x: jitter(0.69, 0.03), y: jitter(0.22, 0.03) + asymH },
    leftWaist:     { x: jitter(0.28, 0.03), y: jitter(0.57, 0.03) },
    rightWaist:    { x: jitter(0.72, 0.03), y: jitter(0.57, 0.03) + asymW },
    spineTop:      { x: 0.50 + trunkShiftX * 0.3, y: jitter(0.22, 0.02) },
    spineBottom:   { x: 0.50 + trunkShiftX,        y: jitter(0.73, 0.03) },
  };
}

function deriveMetrics(lm: Landmarks) {
  const shoulderHeightDiff = Math.abs(lm.leftShoulder.y - lm.rightShoulder.y) * 280;
  const waistImbalance     = Math.abs(lm.leftWaist.y   - lm.rightWaist.y)    * 220;
  const trunkShift         = Math.abs(lm.spineBottom.x  - lm.spineTop.x)     * 160;

  const raw = shoulderHeightDiff * 2.2 + waistImbalance * 1.8 + trunkShift * 2.5;
  const asymmetryScore = Math.min(100, Math.round(raw));

  return {
    shoulderHeightDiff: +shoulderHeightDiff.toFixed(1),
    waistImbalance:     +waistImbalance.toFixed(1),
    trunkShift:         +trunkShift.toFixed(1),
    asymmetryScore,
  };
}

function scoreToRisk(score: number): RiskLevel {
  if (score < 28) return 'low';
  if (score < 58) return 'moderate';
  return 'high';
}

// ---------------------------------------------------------------------------
// Main export – call this from the analysis page
// ---------------------------------------------------------------------------
export function runAnalysis(
  _imageDataUrl: string,
  isDemoMode: boolean,
): Promise<AnalysisResult> {
  return new Promise((resolve) => {
    // Simulate realistic model inference latency (2.2 – 3.4 s)
    const delay = 2200 + Math.random() * 1200;

    setTimeout(() => {
      const landmarks = isDemoMode ? DEMO_LANDMARKS : generateUploadLandmarks();
      const metrics   = isDemoMode ? DEMO_METRICS   : deriveMetrics(landmarks);

      resolve({
        id:         `SCK-${Date.now().toString(36).toUpperCase()}`,
        date:       new Date().toISOString(),
        riskLevel:  scoreToRisk(metrics.asymmetryScore),
        isDemoMode,
        landmarks,
        ...metrics,
      });
    }, delay);
  });
}

// ---------------------------------------------------------------------------
// Human-readable copy helpers
// ---------------------------------------------------------------------------
export const RISK_LABELS: Record<RiskLevel, string> = {
  low:      'Low Visible Asymmetry',
  moderate: 'Moderate Visible Asymmetry',
  high:     'Higher Visible Asymmetry',
};

export const RISK_DESCRIPTIONS: Record<RiskLevel, string> = {
  low:
    'Postural landmarks appear largely symmetrical in this screening image. No significant visible asymmetry was detected in shoulder height, waist level, or trunk alignment during this demo analysis.',
  moderate:
    'Some visible differences in shoulder height and waist alignment were observed in this screening image. While these findings are not diagnostic, they suggest that a medical evaluation may be worthwhile to assess spinal alignment.',
  high:
    'Notable visible differences in shoulder height, waist alignment, and trunk positioning were observed. This demo screening suggests that timely consultation with a healthcare professional—such as a paediatrician or orthopaedic specialist—would be advisable.',
};

export const RISK_NEXT_STEP: Record<RiskLevel, string> = {
  low:
    'Continue routine posture monitoring. Repeat screening in 6–12 months or sooner if visible changes occur.',
  moderate:
    'Consider scheduling an evaluation with a paediatrician or family doctor to discuss these findings. Early assessment is always preferable.',
  high:
    'We recommend consulting a qualified clinician (paediatrician, orthopaedic specialist, or physiotherapist) as soon as conveniently possible.',
};
